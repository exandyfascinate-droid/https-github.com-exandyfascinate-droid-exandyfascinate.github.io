# MacroPulse LIVE — no API key starter

This version is a real local app with live official U.S. macro actuals.

Run:
1. Install Python 3.10+
2. In this folder run: pip install -r requirements.txt
3. Run: python -m uvicorn server:app --reload
4. Open http://127.0.0.1:8000

Live sources:
- BLS public API for CPI, Core CPI, NFP and unemployment actuals.
- Federal Reserve official FOMC calendar for meeting dates.

Important:
No API key is required for the BLS public API for small requests. This version intentionally does NOT fabricate forecast/consensus numbers. A production prediction model needs a legitimate consensus feed. The app is structured so that one can be added later without changing the dashboard.

The prediction engine currently returns WAIT FOR CONSENSUS when it lacks a live forecast. This is safer than generating a fake BUY/SELL signal.


## iPhone website
Deploy this folder to any HTTPS Python host. Open the HTTPS URL in Safari and choose Share -> Add to Home Screen -> Open as Web App. The website is responsive and does not require an App Store installation.
