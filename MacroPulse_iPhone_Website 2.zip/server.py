from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import requests, re
from bs4 import BeautifulSoup
from datetime import datetime, timezone, timedelta

app = FastAPI(title="MacroPulse Live")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
BASE=Path(__file__).parent

# BLS public API: no API key for small requests.
BLS_URL="https://api.bls.gov/publicAPI/v2/timeseries/data/"
SERIES={"CPI":"CUUR0000SA0","Core CPI":"CUUR0000SA0L1E","NFP":"CES0000000001","Unemployment":"LNS14000000"}

def bls_latest(series_id):
    try:
        now=datetime.now()
        payload={"seriesid":[series_id],"startyear":str(now.year-2),"endyear":str(now.year)}
        r=requests.post(BLS_URL,json=payload,timeout=8); r.raise_for_status()
        data=r.json()["Results"]["series"][0]["data"]
        return {"value":data[0]["value"],"period":data[0]["periodName"],"year":data[0]["year"]}
    except Exception as e:
        return {"error":str(e)}

def get_fed_calendar():
    # Official Federal Reserve page. Used only for meeting dates; releases remain authoritative.
    url="https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"
    try:
        html=requests.get(url,timeout=10,headers={"User-Agent":"Mozilla/5.0"}).text
        soup=BeautifulSoup(html,"html.parser")
        text=soup.get_text(" ",strip=True)
        year=str(datetime.now().year)
        # Find date-like strings near the current-year calendar. This is intentionally conservative.
        matches=re.findall(r'(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2}(?:-\d{1,2})?',text)
        return {"source":url,"year":year,"dates":matches[:20]}
    except Exception as e:
        return {"error":str(e)}

@app.get("/api/live")
def live():
    now=datetime.now(timezone.utc)
    return {
        "server_time":now.isoformat(),
        "sources":{
            "bls":"https://www.bls.gov/developers/api_signature_v2.htm",
            "fed":"https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm"
        },
        "actuals":{
            "CPI":bls_latest(SERIES["CPI"]),
            "Core CPI":bls_latest(SERIES["Core CPI"]),
            "NFP":bls_latest(SERIES["NFP"]),
            "Unemployment":bls_latest(SERIES["Unemployment"])
        },
        "fomc":get_fed_calendar(),
        "note":"Forecast/consensus values are not supplied by BLS. The UI labels those fields as unavailable until a licensed/live consensus source is connected."
    }

@app.get("/")
def index():
    return FileResponse(BASE/"index.html")
